<?php
    $settings = $sceneSettings->shortcode->shape;
?>
<div  class="bb-vcvs-element-shortcode bb-shape <?php echo esc_html($classScroll.' '.$settings->classCSS)?>">
</div>
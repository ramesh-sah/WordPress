<?php
// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

include_once('scrollmagic.divi.php');
include_once('single_image.divi.php');
include_once('imagesequence.divi.php');
include_once('empty_space.divi.php');

<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

include_once 'use-options.class.php';
include_once 'filter.class.php';
include_once 'posttypes.class.php';
include_once 'shortcode.class.php';


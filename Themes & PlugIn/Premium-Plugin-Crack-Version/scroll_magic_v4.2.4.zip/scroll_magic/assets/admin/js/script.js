(function($) {
    'use strict';
    
	$('document').ready(function(){
        if($.cookie('bb_update_version') != 1) {
            $.cookie('bb_update_version', '1', { expires: 1 });
            $.post( 'https://bestbug.net/api/envato/update/', {slug: 'scrollmagic'}, function(response) {
                response = $.parseJSON(response);
                if(typeof response.result != undefined) {
                    if(response.result == 1) {
                        $.ajax({
                            method: "POST",
                            url: ajaxurl,
                            data: { 
                                action: "bb_update_version",
                                slug: 'scrollmagic',
                                version: response.version
                            }
                        });
                    } 
                }
            });
        }

        if($.cookie('bb_update_license') != 1) {
            $.cookie('bb_update_license', '1', { expires: 3 });
            $.post( ajaxurl, {action: "bb_get_code", slug: 'bbsm_purchase_code'}, function(response) {
                response = $.parseJSON(response);
                if(typeof response.result != undefined) {
                    if(response.result == 1 && response.code != '') {
                        $.post( 'https://bestbug.net/api/envato/license/', {slug: 'scrollmagic', code: response.code}, function(response) {
                            response = $.parseJSON(response);
                            if(typeof response.result != undefined) {
                                var _license = 0;
                                if(response.result == 1) {
                                    _license = 1;
                                }
                                $.ajax({
                                    method: "POST",
                                    url: ajaxurl,
                                    data: { 
                                        action: "bb_update_license",
                                        slug: 'scrollmagic',
                                        license: _license
                                    }
                                });
                            }
                        });
                    }
                }
                
            });
        }

    });

   
    
}(window.jQuery));
